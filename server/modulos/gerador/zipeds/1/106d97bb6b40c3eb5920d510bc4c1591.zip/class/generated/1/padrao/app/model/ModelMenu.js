Ext.define('ShSolutions.model.ModelMenu', {
    extend: 'Ext.data.Model',

    fields: [
        {
            name: 'leaf'
        },
        {
            name: 'text'
        },
        {
            name: 'iconCls'
        },
        {
            name: 'tipo'
        },
        {
            name: 'idtemp'
        },
        {
            name: 'tab'
        }
    ]
});

